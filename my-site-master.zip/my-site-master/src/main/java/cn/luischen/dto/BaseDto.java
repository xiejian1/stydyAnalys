package cn.luischen.dto;

/**
 * 公共属性的类
 * Created by Donghua.Chen on 2018/4/29.
 */
public class BaseDto {


    /** 用户名 */
    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
